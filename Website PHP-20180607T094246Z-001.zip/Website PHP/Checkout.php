<?php
session_start();
include_once("configuration.php");
include_once("product-list.php")


?>
<html>

<body>
<h1>
    Your order has been paid for and received, your product will arrive in three workdays your total costs are displayed below
</h1>


<a href="index.php" class="btn btn-default">Go to the shop</a>

<p>The home button, so you can browse to your hearts content</p>

</body>
</html>