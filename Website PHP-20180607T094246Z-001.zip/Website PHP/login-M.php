<?php include('Server-M.php') ?>
<!DOCTYPE html>
<html>
<head>
  <title>Registration system PHP and MySQL</title>
  <link rel="stylesheet" type="text/css" href="CSS.css">
</head>
<body>
  <div class="header">
  	<h2>Login Employee</h2>
  </div>
	 
  <form method="post" action="login-M.php">
  	<?php include('errors.php'); ?>
  	<div class="input-group">
  		<label>Username</label>
  		<input type="text" name="Name" >
  	</div>
  	<div class="input-group">
  		<label>Password</label>
  		<input type="password" name="paswoord>
  	</div>
  	<div class="input-group">
  		<button type="submit" class="btn" name="login_user">Login</button>
  	</div>
  	<p>

  	</p>
  </form>
</body>
</html>